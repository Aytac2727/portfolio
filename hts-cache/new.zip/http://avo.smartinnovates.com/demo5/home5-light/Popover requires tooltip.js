<!DOCTYPE html>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<link rel="profile" href="//gmpg.org/xfn/11" />
	<meta name="viewport" content="width=device-width, initial-scale=1" >   	
 
	<title>Page not found &#8211; Avo 05</title>
<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel='dns-prefetch' href='//s.w.org' />
<link rel="alternate" type="application/rss+xml" title="Avo 05 &raquo; Feed" href="http://avo.smartinnovates.com/demo5/feed/" />
<link rel="alternate" type="application/rss+xml" title="Avo 05 &raquo; Comments Feed" href="http://avo.smartinnovates.com/demo5/comments/feed/" />
		<script>
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.0.0\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.0.0\/svg\/","svgExt":".svg","source":{"concatemoji":"http:\/\/avo.smartinnovates.com\/demo5\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.5.3"}};
			!function(e,a,t){var r,n,o,i,p=a.createElement("canvas"),s=p.getContext&&p.getContext("2d");function c(e,t){var a=String.fromCharCode;s.clearRect(0,0,p.width,p.height),s.fillText(a.apply(this,e),0,0);var r=p.toDataURL();return s.clearRect(0,0,p.width,p.height),s.fillText(a.apply(this,t),0,0),r===p.toDataURL()}function l(e){if(!s||!s.fillText)return!1;switch(s.textBaseline="top",s.font="600 32px Arial",e){case"flag":return!c([127987,65039,8205,9895,65039],[127987,65039,8203,9895,65039])&&(!c([55356,56826,55356,56819],[55356,56826,8203,55356,56819])&&!c([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]));case"emoji":return!c([55357,56424,8205,55356,57212],[55357,56424,8203,55356,57212])}return!1}function d(e){var t=a.createElement("script");t.src=e,t.defer=t.type="text/javascript",a.getElementsByTagName("head")[0].appendChild(t)}for(i=Array("flag","emoji"),t.supports={everything:!0,everythingExceptFlag:!0},o=0;o<i.length;o++)t.supports[i[o]]=l(i[o]),t.supports.everything=t.supports.everything&&t.supports[i[o]],"flag"!==i[o]&&(t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&t.supports[i[o]]);t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&!t.supports.flag,t.DOMReady=!1,t.readyCallback=function(){t.DOMReady=!0},t.supports.everything||(n=function(){t.readyCallback()},a.addEventListener?(a.addEventListener("DOMContentLoaded",n,!1),e.addEventListener("load",n,!1)):(e.attachEvent("onload",n),a.attachEvent("onreadystatechange",function(){"complete"===a.readyState&&t.readyCallback()})),(r=t.source||{}).concatemoji?d(r.concatemoji):r.wpemoji&&r.twemoji&&(d(r.twemoji),d(r.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style>
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
	<link rel='stylesheet' id='wp-block-library-css'  href='http://avo.smartinnovates.com/demo5/wp-includes/css/dist/block-library/style.min.css?ver=5.5.3' media='all' />
<link rel='stylesheet' id='wc-block-vendors-style-css'  href='http://avo.smartinnovates.com/demo5/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/vendors-style.css?ver=3.1.0' media='all' />
<link rel='stylesheet' id='wc-block-style-css'  href='http://avo.smartinnovates.com/demo5/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/style.css?ver=3.1.0' media='all' />
<link rel='stylesheet' id='contact-form-7-css'  href='http://avo.smartinnovates.com/demo5/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=5.2.2' media='all' />
<link rel='stylesheet' id='rs-plugin-settings-css'  href='http://avo.smartinnovates.com/demo5/wp-content/plugins/revslider/public/assets/css/rs6.css?ver=6.2.21' media='all' />
<style id='rs-plugin-settings-inline-css'>
#rs-demo-id {}
</style>
<link rel='stylesheet' id='woocommerce-layout-css'  href='http://avo.smartinnovates.com/demo5/wp-content/plugins/woocommerce/assets/css/woocommerce-layout.css?ver=4.5.1' media='all' />
<link rel='stylesheet' id='woocommerce-smallscreen-css'  href='http://avo.smartinnovates.com/demo5/wp-content/plugins/woocommerce/assets/css/woocommerce-smallscreen.css?ver=4.5.1' media='only screen and (max-width: 768px)' />
<link rel='stylesheet' id='woocommerce-general-css'  href='http://avo.smartinnovates.com/demo5/wp-content/plugins/woocommerce/assets/css/woocommerce.css?ver=4.5.1' media='all' />
<style id='woocommerce-inline-inline-css'>
.woocommerce form .form-row .required { visibility: visible; }
</style>
<link rel='stylesheet' id='avo-plugin-style-css'  href='http://avo.smartinnovates.com/demo5/wp-content/plugins/avo_plugin/widgets/css/style.css?ver=1.0.0' media='all' />
<link rel='stylesheet' id='avo-fonts-css'  href='//fonts.googleapis.com/css?family=Roboto%3A300%2C400%2C400i%2C500%2C600%2C600i%2C700%2C700i%2C800%2C800i%2C900%7CPoppins%3A300%2C400%2C500%2C600%2C700%2C800%2C900%7CBarlow+Condensed%3A300%2C400%2C500%2C600%2C700%2C800%2C900&#038;ver=1.0.0' media='all' />
<link rel='stylesheet' id='bootstrap-css'  href='http://avo.smartinnovates.com/demo5/wp-content/themes/avo/css/bootstrap.min.css?ver=1' media='all' />
<link rel='stylesheet' id='font-awesome-css'  href='http://avo.smartinnovates.com/demo5/wp-content/plugins/elementor/assets/lib/font-awesome/css/font-awesome.min.css?ver=4.7.0' media='all' />
<link rel='stylesheet' id='fontawesome-css'  href='http://avo.smartinnovates.com/demo5/wp-content/themes/avo/css/fontawesome.min.css?ver=1' media='all' />
<link rel='stylesheet' id='icon-font-css'  href='http://avo.smartinnovates.com/demo5/wp-content/themes/avo/css/icon-font.min.css?ver=1' media='all' />
<link rel='stylesheet' id='ionicons-css'  href='http://avo.smartinnovates.com/demo5/wp-content/themes/avo/css/ionicons.min.css?ver=1' media='all' />
<link rel='stylesheet' id='magnific-popup-css'  href='http://avo.smartinnovates.com/demo5/wp-content/themes/avo/css/magnific-popup.css?ver=1' media='all' />
<link rel='stylesheet' id='animate-css'  href='http://avo.smartinnovates.com/demo5/wp-content/themes/avo/css/animate.css?ver=1' media='all' />
<link rel='stylesheet' id='magic-css'  href='http://avo.smartinnovates.com/demo5/wp-content/themes/avo/css/magic.css?ver=1' media='all' />
<link rel='stylesheet' id='slick-css'  href='http://avo.smartinnovates.com/demo5/wp-content/themes/avo/css/slick.css?ver=1' media='all' />
<link rel='stylesheet' id='jquery-fatnav-css'  href='http://avo.smartinnovates.com/demo5/wp-content/themes/avo/css/jquery.fatNav.css?ver=1' media='all' />
<link rel='stylesheet' id='animate-headline-css'  href='http://avo.smartinnovates.com/demo5/wp-content/themes/avo/css/animate.headline.css?ver=1' media='all' />
<link rel='stylesheet' id='splitting-css'  href='http://avo.smartinnovates.com/demo5/wp-content/themes/avo/css/splitting.css?ver=1' media='all' />
<link rel='stylesheet' id='splitting-cells-css'  href='http://avo.smartinnovates.com/demo5/wp-content/themes/avo/css/splitting-cells.css?ver=1' media='all' />
<link rel='stylesheet' id='avo-style-css'  href='http://avo.smartinnovates.com/demo5/wp-content/themes/avo/style.css?ver=1.0.0' media='all' />
<style id='avo-style-inline-css'>

		.load-circle{border-top-color: #75DAB4;}
		

		.cursor-inner,.cursor-inner.cursor-hover,.avo-slider.style-1 .slider-line, .avo-slider.style-1 .dsc-btn-style1, .avo-slider.style-1 .left-box-slider .slider-line, .avo-slider.style-1 .center-box-slider .slider-line, .avo-portfolio-single .slider-line, .avo-portfolio-single .dsc-btn-style1, .avo-portfolio-single .left-box-slider .slider-line, .avo-portfolio-single .center-box-slider .slider-line, .team-3 .team-info .team-sicon li a:hover, .skills-box .skill-progress .progres, .avo-progress-bar.style-1 .skills-box .skill-progress .progres,.share-box a:hover,.title-related-post:after,  .widget_categories ul li.cat-item a:hover + span, .widget_archive ul li a:hover + span,.comment-reply-link:hover, h2.comments-title:after, .dsc-btn-style3,.cart-contents-count, .woocommerce span.onsale, .info-box.style-7 .mas-item .bg-color, .img-comp-slider, .content-btn:hover, .tags-bottom a:hover, .widget-border , .form-submit #submit , .navigation > li.sfHover > a:before
		{background-color:#75DAB4;}

		::selection 
		{background:#75DAB4;}

		::-moz-selection 
		{background:#75DAB4;}

		.woocommerce .button:hover, .woocommerce-checkout .checkout_coupon button.button:hover,  .woocommerce-checkout .woocommerce-checkout-review-order .woocommerce-checkout-payment .place-order button.button:hover
		{background-color:#75DAB4 !important;}

		.progress-wrap svg.progress-circle path, .port-inner .port-dbox a span svg:hover, .avo-product.style-2 .port-inner .port-dbox a span svg:hover 
		{stroke:#75DAB4;}

		.dsc-heading-style1 h5,.avo-mc4wp-1 .mc4wp-form-fields input[type=submit],a:hover,blockquote::before,.content-title span,.table-content h3 > span,.btn-curve.btn-lit:hover span, .btn-curve.btn-color:hover span, .progress-wrap::after,th a,td a,#preloader .loading-text,.button.style-1.btn-lit:hover span,.button.style-1.btn-color:hover span,.button.style-2 .vid-icon .vid span,.avo-header.style-3 .works-header .capt h2 span,.avo-header.style-4 .pages-header .cont .path .active, .avo-header.style-4 .pages-header .cont .path span, .avo-header.style-5 .sec-head h6, .header-top h6 i,.white-header .header-icon li.current-menu-parent > a, .white-header .header-icon li.current_page_item > a,.white-header .navigation li a:hover,.white-header .navigation li.current-menu-parent > a,.white-header .navigation li.current_page_item > a,.white-header .menu-wrapper .menu ul li ul li a:hover,.white-header .menu-wrapper .menu ul li ul li.current_page_item > a, .white-header .menu-wrapper .menu ul li.current-menu-parent > a, .white-header .menu-wrapper .menu ul li.current_page_item > a, .white-header .menu-wrapper .navigation li ul li a:hover,.white-header .menu-wrapper .navigation li ul li.current_page_item > a,.menu-wrapper .menu ul li ul li a:hover, .menu-wrapper .menu ul li ul li.current_page_item > a, .menu-wrapper .navigation li ul li a:hover, .menu-wrapper .navigation li ul li.current_page_item > a, .custom-absolute-menu .is-sticky .navigation li a:hover, .custom-absolute-menu .is-sticky .navigation li.current-menu-item a, .custom-absolute-menu .is-sticky .menu-wrapper .menu ul li a:hover, .custom-absolute-menu .is-sticky .menu-wrapper .menu ul li.current-menu-item a, .custom-absolute-menu .navigation .sub-menu li a:hover, .custom-absolute-menu .navigation .sub-menu li.current-menu-item a, .custom-absolute-menu .menu-wrapper .menu ul.sub-menu li a:hover, .custom-absolute-menu .menu-wrapper .menu ul.sub-menu li.current-menu-item a, .header-icon li a:hover,.btn-nav-top a:hover, .avo-slider.style-1 .home-slider .slick-arrow:hover,  .avo-slider.style-1 .slider-btn:hover,  .avo-slider.style-1 .dsc-btn-style2,.slider.style-6 .parallax-slider .caption .thin, .slider.style-6 .parallax-slider .caption .thin span, .cta__slider-item .caption .thin, .freelancer .cont h6, .pages-header .cont .path .active, .works-header .capt h2 span, .avo-slider.style-7 .slider .parallax-slider .caption .thin, .avo-slider.style-7 .slider .parallax-slider .caption .thin span, .avo-portfolio-single .home-slider .slick-arrow:hover, .avo-portfolio-single .slider-btn:hover,.avo-portfolio-single .dsc-btn-style2 , .showcase.style-2 [data-overlay-dark] h1, .showcase.style-2 [data-overlay-dark] h2, .showcase.style-2 [data-overlay-dark] h3, .showcase.style-2 [data-overlay-dark] h4, .showcase.style-2 [data-overlay-dark] h5, .showcase.style-2 [data-overlay-dark] h6, .showcase.style-2 [data-overlay-dark] span, .showcase.style-2 .showcase-carus .copy-cap .cap h1 .stroke,  .showcase.style-3 .showcase-carus.circle-slide .copy-cap .cap h1 .stroke, .showcase.style-3 .showcase-carus.circle-slide .copy-cap .cap h1 span, .feature-1:hover .avo-icon , .feature-1 .avo-icon, .feature-2 .avo-icon, .feature-3 .avo-icon, .feature-3:hover .avo-icon, .avo-featured.style-3 .min-area .content ul.feat li h6 span, .port-filter a.active, .port-filter a:hover, .portfolio-2 .port-inner:hover .dbox-relative h3 a:hover, .portfolio-2 .port-inner .port-dbox a span:hover, .portfolio-type-three .dbox-relative p,.portfolio-type-three .port-inner .dbox-relative a span:hover, .portfolio.style-4 .content .cont h6, .portfolio.style-4 .noraidus .cont h6 , .portfolio.style-5 .filtering span.active, .portfolio.style-5 .filtering.smplx span.active, .portfolio.style-6 .work-carousel .content .cont h6 , .portfolio.style-6 .work-carousel .noraidus .cont h6, .team-soc-list a:hover, .team-sicon li a, .team-sicon li a:hover, .team-1 p, .team-list-two .team-sicon li a, .team-3 .team-info p, .team-3 .team-info .team-sicon li a, .avo-team.style-4 .team h6, .avo-team.style-4 .team .item .info .social a,.testimonial.style-1 .rating-icon,  .testimonial.style-3 .item .info .author-name, .wpcf7-submit , .dark-page .wpcf7-submit, .content-btn, .color-bg .wpcf7-submit, span.your-name:before, span.your-email:before, span.cell-phone:before,  span.subject:before, .footer a,span.your-message:before, .footer a, .blog-post-list a:hover h3, .post-meta a, .post-meta li, .blog-2 .content-btn, .blog-content .blog-post p a, a .entry-title:hover, .post-detail > li a:hover, .post-detail > li i, .related-cat i, h3.related-title:hover,.imgpagi-box p, .img-pagination a:hover .img-pagi .lnr, .blog-post-list.blog-style-1 .blog-col-inner .excerpt-box a:hover h3, .blog-post-list.blog-style-1 .blog-col-inner .excerpt-box .content-btn:hover , .blog-post-list.blog-style-1 .blog-col-inner .excerpt-box .post-meta a , .blog-post-list.blog-style-1 .blog-col-inner .excerpt-box .post-meta li,  .widget ul li a:before, .widget.widget_recent_comments > ul > li:before, .widget.widget_recent_entries ul li a:before, .widget.widget_archive ul li a:before, .widget.widget_meta ul li a:before,.tagcloud a:hover, .abtw-soc a:hover, .form-submit #submit:hover, .screen-reader-text:focus, .dsc-btn-style3:hover .elementor-button, .dsc-btn-style-4, .woocommerce-info a, .woocommerce div.product p.price, .woocommerce div.product span.price,  .woocommerce .woocommerce-tabs .woocommerce-Tabs-panel .woocommerce-Reviews #comments .woocommerce-Reviews-title span, .woocommerce .woocommerce-tabs .woocommerce-Tabs-panel .woocommerce-Reviews #comments .commentlist .comment .comment_container .comment-text .star-rating, .woocommerce-account .woocommerce .woocommerce-MyAccount-content a, .woocommerce-account .woocommerce .woocommerce-MyAccount-navigation ul li a:hover, .woocommerce-Reviews .commentlist .review .comment_container .comment-text .meta .woocommerce-review__dash, .woocommerce nav.woocommerce-pagination ul li a, .woocommerce nav.woocommerce-pagination ul li span, .woocommerce div.product form.cart .group_table td.woocommerce-grouped-product-list-item__label label a, .img-box-slider .slick-slide:hover .box-cont h3, .img-box-slider h3 a:hover, .img-box-slider .fa-angle-left.slick-arrow, .img-box-slider .fa-angle-right.slick-arrow, .img-box-slider .slick-dots li.slick-active button:before, .img-box-slider.imgbox-slider-2 .item .box-cont .feature-btn:hover, .info-box.style-5 .item-box .icon, .info-box.style-5 .mas-item .icon,  .info-box.style-5 .step-item .icon, .info-box.style-5 .item .icon, .info-box.style-6 .icon, .info-box.style-7 .mas-item .icon , .post-list.style-1 .item .cont .info a.author, .post-list.style-2 .item .cont .info .tag, .post-list.style-3 .item .cont .info .tagm, #wp-calendar tbody tr td, #wp-calendar thead, .post-pager p, code, .img-box-slider.imgbox-slider-2 .item .box-cont .feature-btn,.text-color    
		{color:#75DAB4;}

	    .woocommerce table td.product-remove a:hover, .woocommerce .woocommerce-tabs ul.tabs li.active a, .woocommerce .woocommerce-tabs ul.tabs li a:hover, .searchform::after
      	{color: #75DAB4 !important;}

		.content-title:after,.to-top, .btn-curve.btn-color,.pace .pace-progress,.button.style-1.btn-color,.avo-title.style-1 .sub-title span,.menu-wrapper > .menu > ul > li > a:before , .custom-absolute-menu .is-sticky .navigation > li > a:before,.btn-nav-top a, .search-icon-header .searchform::after, .avo-slider.style-1 .slider-style-2 .slider-subtitle,  .cta__slider-item .caption .bottom-corn:before, .avo-portfolio-single .slider-style-2 .slider-subtitle, .feature-4 .avo-icon, .avo-featured.style-2 .items .item-img .tlinks a:last-of-type, .avo-featured.style-2 .items .item-img .new , .other-portfolio .port-box , .portfolio-1 .port-inner .dbox-relative, .portfolio-type-three .port-inner:hover .dbox-relative a span, .portfolio.style-5 .filtering span:after, .portfolio.style-5 .filtering.smplx span:after,.team-soc-list a, .team-2 .port-box, .avo-team.style-4 .team .slick-dots li.slick-active button, .avo-team.style-4 .team .slick-dots li button:before, .skills-box .skill-progress .progres:after, .avo-progress-bar.style-1 .skills-box .skill-progress .progres:after, .wpcf7-submit:hover, .dsc-footer-style-2 .mc4wp-form-fields input[type=submit]:hover, .dsc-footer-style-3 h3:after, .dsc-footer-style-3 .mc4wp-form-fields input[type=submit] , .blog-link-img , .blog-link-img .bl-icon, .blog-post-list.blog-style-1 .blog-col-inner .blog-link-img, .blog-post-list.blog-style-1 .blog-col-inner .blog-link-img .bl-icon, .post-style-3 .entry-header .post-date, .ab-bordering, .abtw-soc a, .dsc-btn-style3  , .dsc-btn-style-4:hover, .woocommerce div.product form.cart .button, .img-box-slider .slick-dots li button:before,  .img-box-slider.imgbox-slider-2 .item .box-cont .feature-btn, .info-box.style-5 .mas-item .bg-color, .info-box.style-5 .step-item.xcolor, .post-list.style-2 .item.list .cont .date, .post-list.style-3 .item.list .cont .date, .avo-mc4wp-1 .mc4wp-form-fields input[type=submit]:hover
		{background:#75DAB4;}

		.cell-left-border, blockquote, .cell-right-border,.cursor-outer,.btn-curve.btn-color, .load-circle, .button.style-1.btn-color,.menu-wrapper ul li ul,.custom-absolute-menu, .btn-nav-top a,.btn-nav-top a:hover, .avo-slider.style-1 .dsc-btn-style1, .avo-portfolio-single .dsc-btn-style1, .feature-1:hover .avo-icon, .feature-1 .avo-icon, .feature-4 .avo-icon, .avo-featured.style-3 .min-area .content ul.feat li h6 span, .work-process.style-1 .item .box-img .bg-img, .portfolio-2 .port-inner .port-dbox a span:hover, .portfolio-type-three .port-inner:hover .dbox-relative a span , .portfolio-type-three .port-inner:hover .dbox-relative h3,.team-1 .team-info, .team-3 .team-info, .team-3 .team-info .team-sicon li a, .testimonial.style-2 .arrows .next:hover, .testimonial.style-2 .arrows .prev:hover, .testimonial.style-3 .arrows .next:hover, .testimonial.style-3 .arrows .prev:hover , .skills-box .skill-progress .progres:before , form input:focus, form textarea:focus, .comment-respond form input:focus, .comment-respond form textarea:focus, .wpcf7-submit,.wpcf7-submit:hover, .dark-page .wpcf7-submit, .content-btn,  .error-title,.blog-2 .content-btn i,  #related_posts .related-inner:hover, .related-inner, .blog-post-list.blog-style-1 .blog-col-inner .excerpt-box .content-btn:hover, .tagcloud a:hover,  .form-submit #submit,.form-submit #submit:hover,  .dsc-btn-style3:hover, .dsc-btn-style-4, .dsc-btn-style-4:hover, .woocommerce .woocommerce-tabs ul.tabs li a:hover,  .woocommerce .woocommerce-tabs ul.tabs li.active a, .img-box-slider.imgbox-slider-2 .item .box-cont .feature-btn 
		{border-color:#75DAB4;}

		.woocommerce .button:hover
		{border-color:#75DAB4 !important;}

		.avo-progress-bar.style-1 .skills-box .skill-progress .progres:before
		{border-top-color:#75DAB4;}

		.to-top::before,.to-top::after,.blog-gallery a i
		{background: #75DAB4 none repeat scroll 0 0;}

		.showcase.style-2 .showcase-carus .caption h1 .stroke, .showcase.style-2 .showcase.style-2 .showcase-carus .copy-cap h1 .stroke, .showcase.style-3 .showcase-carus.circle-slide .caption h1 .stroke, .showcase.style-3 .copy-cap h1 .stroke, .showcase.style-3 .caption h1 span, .showcase.style-3 .copy-cap h1 span, .showcase.style-3 .copy-cap .cap h1 .stroke, .showcase.style-3 .copy-cap .cap h1 span, .showcase.style-3 .showcase-carus.circle-slide .caption h1 span, .showcase.style-3 .showcase.style-3 .showcase-carus.circle-slide .copy-cap h1 span
		{-webkit-text-stroke: 1px #75DAB4;}
		
		.p-table a ,.blog-slider .slide-nav:hover,.work-content .slide-nav:hover,.tagcloud a:hover
			{color:#fff;}

		.dsc-btn-style3
			{background-color:#fff;}
		
		
a:hover{color:#75DAB4;}
a{color:#999999;}
h1, h2, h3, h4, h5, h6{color:#000000;} 
body{color:#666666;}
.footer{background-color:#202020;}
.custom-absolute-menu{border-color: #FFFFFF;}

		.cursor-inner,.cursor-inner.cursor-hover,.avo-slider.style-1 .slider-line, .avo-slider.style-1 .dsc-btn-style1, .avo-slider.style-1 .left-box-slider .slider-line, .avo-slider.style-1 .center-box-slider .slider-line, .avo-portfolio-single .slider-line, .avo-portfolio-single .dsc-btn-style1, .avo-portfolio-single .left-box-slider .slider-line, .avo-portfolio-single .center-box-slider .slider-line, .team-3 .team-info .team-sicon li a:hover, .skills-box .skill-progress .progres, .avo-progress-bar.style-1 .skills-box .skill-progress .progres,.share-box a:hover,.title-related-post:after,  .widget_categories ul li.cat-item a:hover + span, .widget_archive ul li a:hover + span,.comment-reply-link:hover, h2.comments-title:after, .dsc-btn-style3,.cart-contents-count, .woocommerce span.onsale, .info-box.style-7 .mas-item .bg-color, .img-comp-slider, .content-btn:hover, .tags-bottom a:hover, .widget-border , .form-submit #submit , .navigation > li.sfHover > a:before
		{background-color:#75DAB4;}

		::selection 
		{background:#75DAB4;}

		::-moz-selection 
		{background:#75DAB4;}

		.woocommerce .button:hover, .woocommerce-checkout .checkout_coupon button.button:hover,  .woocommerce-checkout .woocommerce-checkout-review-order .woocommerce-checkout-payment .place-order button.button:hover
		{background-color:#75DAB4 !important;}

		.progress-wrap svg.progress-circle path, .port-inner .port-dbox a span svg:hover, .avo-product.style-2 .port-inner .port-dbox a span svg:hover 
		{stroke:#75DAB4;}

		.dsc-heading-style1 h5,.avo-mc4wp-1 .mc4wp-form-fields input[type=submit],a:hover,blockquote::before,.content-title span,.table-content h3 > span,.btn-curve.btn-lit:hover span, .btn-curve.btn-color:hover span, .progress-wrap::after,th a,td a,#preloader .loading-text,.button.style-1.btn-lit:hover span,.button.style-1.btn-color:hover span,.button.style-2 .vid-icon .vid span,.avo-header.style-3 .works-header .capt h2 span,.avo-header.style-4 .pages-header .cont .path .active, .avo-header.style-4 .pages-header .cont .path span, .avo-header.style-5 .sec-head h6, .header-top h6 i,.white-header .header-icon li.current-menu-parent > a, .white-header .header-icon li.current_page_item > a,.white-header .navigation li a:hover,.white-header .navigation li.current-menu-parent > a,.white-header .navigation li.current_page_item > a,.white-header .menu-wrapper .menu ul li ul li a:hover,.white-header .menu-wrapper .menu ul li ul li.current_page_item > a, .white-header .menu-wrapper .menu ul li.current-menu-parent > a, .white-header .menu-wrapper .menu ul li.current_page_item > a, .white-header .menu-wrapper .navigation li ul li a:hover,.white-header .menu-wrapper .navigation li ul li.current_page_item > a,.menu-wrapper .menu ul li ul li a:hover, .menu-wrapper .menu ul li ul li.current_page_item > a, .menu-wrapper .navigation li ul li a:hover, .menu-wrapper .navigation li ul li.current_page_item > a, .custom-absolute-menu .is-sticky .navigation li a:hover, .custom-absolute-menu .is-sticky .navigation li.current-menu-item a, .custom-absolute-menu .is-sticky .menu-wrapper .menu ul li a:hover, .custom-absolute-menu .is-sticky .menu-wrapper .menu ul li.current-menu-item a, .custom-absolute-menu .navigation .sub-menu li a:hover, .custom-absolute-menu .navigation .sub-menu li.current-menu-item a, .custom-absolute-menu .menu-wrapper .menu ul.sub-menu li a:hover, .custom-absolute-menu .menu-wrapper .menu ul.sub-menu li.current-menu-item a, .header-icon li a:hover,.btn-nav-top a:hover, .avo-slider.style-1 .home-slider .slick-arrow:hover,  .avo-slider.style-1 .slider-btn:hover,  .avo-slider.style-1 .dsc-btn-style2,.slider.style-6 .parallax-slider .caption .thin, .slider.style-6 .parallax-slider .caption .thin span, .cta__slider-item .caption .thin, .freelancer .cont h6, .pages-header .cont .path .active, .works-header .capt h2 span, .avo-slider.style-7 .slider .parallax-slider .caption .thin, .avo-slider.style-7 .slider .parallax-slider .caption .thin span, .avo-portfolio-single .home-slider .slick-arrow:hover, .avo-portfolio-single .slider-btn:hover,.avo-portfolio-single .dsc-btn-style2 , .showcase.style-2 [data-overlay-dark] h1, .showcase.style-2 [data-overlay-dark] h2, .showcase.style-2 [data-overlay-dark] h3, .showcase.style-2 [data-overlay-dark] h4, .showcase.style-2 [data-overlay-dark] h5, .showcase.style-2 [data-overlay-dark] h6, .showcase.style-2 [data-overlay-dark] span, .showcase.style-2 .showcase-carus .copy-cap .cap h1 .stroke,  .showcase.style-3 .showcase-carus.circle-slide .copy-cap .cap h1 .stroke, .showcase.style-3 .showcase-carus.circle-slide .copy-cap .cap h1 span, .feature-1:hover .avo-icon , .feature-1 .avo-icon, .feature-2 .avo-icon, .feature-3 .avo-icon, .feature-3:hover .avo-icon, .avo-featured.style-3 .min-area .content ul.feat li h6 span, .port-filter a.active, .port-filter a:hover, .portfolio-2 .port-inner:hover .dbox-relative h3 a:hover, .portfolio-2 .port-inner .port-dbox a span:hover, .portfolio-type-three .dbox-relative p,.portfolio-type-three .port-inner .dbox-relative a span:hover, .portfolio.style-4 .content .cont h6, .portfolio.style-4 .noraidus .cont h6 , .portfolio.style-5 .filtering span.active, .portfolio.style-5 .filtering.smplx span.active, .portfolio.style-6 .work-carousel .content .cont h6 , .portfolio.style-6 .work-carousel .noraidus .cont h6, .team-soc-list a:hover, .team-sicon li a, .team-sicon li a:hover, .team-1 p, .team-list-two .team-sicon li a, .team-3 .team-info p, .team-3 .team-info .team-sicon li a, .avo-team.style-4 .team h6, .avo-team.style-4 .team .item .info .social a,.testimonial.style-1 .rating-icon,  .testimonial.style-3 .item .info .author-name, .wpcf7-submit , .dark-page .wpcf7-submit, .content-btn, .color-bg .wpcf7-submit, span.your-name:before, span.your-email:before, span.cell-phone:before,  span.subject:before, .footer a,span.your-message:before, .footer a, .blog-post-list a:hover h3, .post-meta a, .post-meta li, .blog-2 .content-btn, .blog-content .blog-post p a, a .entry-title:hover, .post-detail > li a:hover, .post-detail > li i, .related-cat i, h3.related-title:hover,.imgpagi-box p, .img-pagination a:hover .img-pagi .lnr, .blog-post-list.blog-style-1 .blog-col-inner .excerpt-box a:hover h3, .blog-post-list.blog-style-1 .blog-col-inner .excerpt-box .content-btn:hover , .blog-post-list.blog-style-1 .blog-col-inner .excerpt-box .post-meta a , .blog-post-list.blog-style-1 .blog-col-inner .excerpt-box .post-meta li,  .widget ul li a:before, .widget.widget_recent_comments > ul > li:before, .widget.widget_recent_entries ul li a:before, .widget.widget_archive ul li a:before, .widget.widget_meta ul li a:before,.tagcloud a:hover, .abtw-soc a:hover, .form-submit #submit:hover, .screen-reader-text:focus, .dsc-btn-style3:hover .elementor-button, .dsc-btn-style-4, .woocommerce-info a, .woocommerce div.product p.price, .woocommerce div.product span.price,  .woocommerce .woocommerce-tabs .woocommerce-Tabs-panel .woocommerce-Reviews #comments .woocommerce-Reviews-title span, .woocommerce .woocommerce-tabs .woocommerce-Tabs-panel .woocommerce-Reviews #comments .commentlist .comment .comment_container .comment-text .star-rating, .woocommerce-account .woocommerce .woocommerce-MyAccount-content a, .woocommerce-account .woocommerce .woocommerce-MyAccount-navigation ul li a:hover, .woocommerce-Reviews .commentlist .review .comment_container .comment-text .meta .woocommerce-review__dash, .woocommerce nav.woocommerce-pagination ul li a, .woocommerce nav.woocommerce-pagination ul li span, .woocommerce div.product form.cart .group_table td.woocommerce-grouped-product-list-item__label label a, .img-box-slider .slick-slide:hover .box-cont h3, .img-box-slider h3 a:hover, .img-box-slider .fa-angle-left.slick-arrow, .img-box-slider .fa-angle-right.slick-arrow, .img-box-slider .slick-dots li.slick-active button:before, .img-box-slider.imgbox-slider-2 .item .box-cont .feature-btn:hover, .info-box.style-5 .item-box .icon, .info-box.style-5 .mas-item .icon,  .info-box.style-5 .step-item .icon, .info-box.style-5 .item .icon, .info-box.style-6 .icon, .info-box.style-7 .mas-item .icon , .post-list.style-1 .item .cont .info a.author, .post-list.style-2 .item .cont .info .tag, .post-list.style-3 .item .cont .info .tagm, #wp-calendar tbody tr td, #wp-calendar thead, .post-pager p, code, .img-box-slider.imgbox-slider-2 .item .box-cont .feature-btn,.text-color    
		{color:#75DAB4;}

	    .woocommerce table td.product-remove a:hover, .woocommerce .woocommerce-tabs ul.tabs li.active a, .woocommerce .woocommerce-tabs ul.tabs li a:hover, .searchform::after
      	{color: #75DAB4 !important;}

		.content-title:after,.to-top, .btn-curve.btn-color,.pace .pace-progress,.button.style-1.btn-color,.avo-title.style-1 .sub-title span,.menu-wrapper > .menu > ul > li > a:before , .custom-absolute-menu .is-sticky .navigation > li > a:before,.btn-nav-top a, .search-icon-header .searchform::after, .avo-slider.style-1 .slider-style-2 .slider-subtitle,  .cta__slider-item .caption .bottom-corn:before, .avo-portfolio-single .slider-style-2 .slider-subtitle, .feature-4 .avo-icon, .avo-featured.style-2 .items .item-img .tlinks a:last-of-type, .avo-featured.style-2 .items .item-img .new , .other-portfolio .port-box , .portfolio-1 .port-inner .dbox-relative, .portfolio-type-three .port-inner:hover .dbox-relative a span, .portfolio.style-5 .filtering span:after, .portfolio.style-5 .filtering.smplx span:after,.team-soc-list a, .team-2 .port-box, .avo-team.style-4 .team .slick-dots li.slick-active button, .avo-team.style-4 .team .slick-dots li button:before, .skills-box .skill-progress .progres:after, .avo-progress-bar.style-1 .skills-box .skill-progress .progres:after, .wpcf7-submit:hover, .dsc-footer-style-2 .mc4wp-form-fields input[type=submit]:hover, .dsc-footer-style-3 h3:after, .dsc-footer-style-3 .mc4wp-form-fields input[type=submit] , .blog-link-img , .blog-link-img .bl-icon, .blog-post-list.blog-style-1 .blog-col-inner .blog-link-img, .blog-post-list.blog-style-1 .blog-col-inner .blog-link-img .bl-icon, .post-style-3 .entry-header .post-date, .ab-bordering, .abtw-soc a, .dsc-btn-style3  , .dsc-btn-style-4:hover, .woocommerce div.product form.cart .button, .img-box-slider .slick-dots li button:before,  .img-box-slider.imgbox-slider-2 .item .box-cont .feature-btn, .info-box.style-5 .mas-item .bg-color, .info-box.style-5 .step-item.xcolor, .post-list.style-2 .item.list .cont .date, .post-list.style-3 .item.list .cont .date, .avo-mc4wp-1 .mc4wp-form-fields input[type=submit]:hover
		{background:#75DAB4;}

		.cell-left-border, blockquote, .cell-right-border,.cursor-outer,.btn-curve.btn-color, .load-circle, .button.style-1.btn-color,.menu-wrapper ul li ul,.custom-absolute-menu, .btn-nav-top a,.btn-nav-top a:hover, .avo-slider.style-1 .dsc-btn-style1, .avo-portfolio-single .dsc-btn-style1, .feature-1:hover .avo-icon, .feature-1 .avo-icon, .feature-4 .avo-icon, .avo-featured.style-3 .min-area .content ul.feat li h6 span, .work-process.style-1 .item .box-img .bg-img, .portfolio-2 .port-inner .port-dbox a span:hover, .portfolio-type-three .port-inner:hover .dbox-relative a span , .portfolio-type-three .port-inner:hover .dbox-relative h3,.team-1 .team-info, .team-3 .team-info, .team-3 .team-info .team-sicon li a, .testimonial.style-2 .arrows .next:hover, .testimonial.style-2 .arrows .prev:hover, .testimonial.style-3 .arrows .next:hover, .testimonial.style-3 .arrows .prev:hover , .skills-box .skill-progress .progres:before , form input:focus, form textarea:focus, .comment-respond form input:focus, .comment-respond form textarea:focus, .wpcf7-submit,.wpcf7-submit:hover, .dark-page .wpcf7-submit, .content-btn,  .error-title,.blog-2 .content-btn i,  #related_posts .related-inner:hover, .related-inner, .blog-post-list.blog-style-1 .blog-col-inner .excerpt-box .content-btn:hover, .tagcloud a:hover,  .form-submit #submit,.form-submit #submit:hover,  .dsc-btn-style3:hover, .dsc-btn-style-4, .dsc-btn-style-4:hover, .woocommerce .woocommerce-tabs ul.tabs li a:hover,  .woocommerce .woocommerce-tabs ul.tabs li.active a, .img-box-slider.imgbox-slider-2 .item .box-cont .feature-btn 
		{border-color:#75DAB4;}

		.woocommerce .button:hover
		{border-color:#75DAB4 !important;}

		.avo-progress-bar.style-1 .skills-box .skill-progress .progres:before
		{border-top-color:#75DAB4;}

		.to-top::before,.to-top::after,.blog-gallery a i
		{background: #75DAB4 none repeat scroll 0 0;}

		.showcase.style-2 .showcase-carus .caption h1 .stroke, .showcase.style-2 .showcase.style-2 .showcase-carus .copy-cap h1 .stroke, .showcase.style-3 .showcase-carus.circle-slide .caption h1 .stroke, .showcase.style-3 .copy-cap h1 .stroke, .showcase.style-3 .caption h1 span, .showcase.style-3 .copy-cap h1 span, .showcase.style-3 .copy-cap .cap h1 .stroke, .showcase.style-3 .copy-cap .cap h1 span, .showcase.style-3 .showcase-carus.circle-slide .caption h1 span, .showcase.style-3 .showcase.style-3 .showcase-carus.circle-slide .copy-cap h1 span
		{-webkit-text-stroke: 1px #75DAB4;}
		
		.p-table a ,.blog-slider .slide-nav:hover,.work-content .slide-nav:hover,.tagcloud a:hover
			{color:#fff;}

		.dsc-btn-style3
			{background-color:#fff;}
		
		
a:hover{color:#75DAB4;}
a{color:#999999;}
h1, h2, h3, h4, h5, h6{color:#000000;} 
body{color:#666666;}
.footer{background-color:#202020;}
.custom-absolute-menu{border-color: #FFFFFF;}
body {cursor: none!important;}
</style>
<script src='http://avo.smartinnovates.com/demo5/wp-includes/js/jquery/jquery.js?ver=1.12.4-wp' id='jquery-core-js'></script>
<script src='http://avo.smartinnovates.com/demo5/wp-content/plugins/revslider/public/assets/js/rbtools.min.js?ver=6.2.21' id='tp-tools-js'></script>
<script src='http://avo.smartinnovates.com/demo5/wp-content/plugins/revslider/public/assets/js/rs6.min.js?ver=6.2.21' id='revmin-js'></script>
<script src='http://avo.smartinnovates.com/demo5/wp-content/themes/avo/js/modernizr.js?ver=5.5.3' id='modernizr-js'></script>
<link rel="https://api.w.org/" href="http://avo.smartinnovates.com/demo5/wp-json/" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://avo.smartinnovates.com/demo5/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://avo.smartinnovates.com/demo5/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 5.5.3" />
<meta name="generator" content="WooCommerce 4.5.1" />
<meta name="framework" content="Redux 4.1.20" />	<noscript><style>.woocommerce-product-gallery{ opacity: 1 !important; }</style></noscript>
	<style>.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style><meta name="generator" content="Powered by Slider Revolution 6.2.21 - responsive, Mobile-Friendly Slider Plugin for WordPress with comfortable drag and drop interface." />
<link rel="icon" href="http://avo.smartinnovates.com/demo5/wp-content/uploads/sites/12/2020/10/cropped-Favicon-32x32.png" sizes="32x32" />
<link rel="icon" href="http://avo.smartinnovates.com/demo5/wp-content/uploads/sites/12/2020/10/cropped-Favicon-192x192.png" sizes="192x192" />
<link rel="apple-touch-icon" href="http://avo.smartinnovates.com/demo5/wp-content/uploads/sites/12/2020/10/cropped-Favicon-180x180.png" />
<meta name="msapplication-TileImage" content="http://avo.smartinnovates.com/demo5/wp-content/uploads/sites/12/2020/10/cropped-Favicon-270x270.png" />
<script type="text/javascript">function setREVStartSize(e){
			//window.requestAnimationFrame(function() {				 
				window.RSIW = window.RSIW===undefined ? window.innerWidth : window.RSIW;	
				window.RSIH = window.RSIH===undefined ? window.innerHeight : window.RSIH;	
				try {								
					var pw = document.getElementById(e.c).parentNode.offsetWidth,
						newh;
					pw = pw===0 || isNaN(pw) ? window.RSIW : pw;
					e.tabw = e.tabw===undefined ? 0 : parseInt(e.tabw);
					e.thumbw = e.thumbw===undefined ? 0 : parseInt(e.thumbw);
					e.tabh = e.tabh===undefined ? 0 : parseInt(e.tabh);
					e.thumbh = e.thumbh===undefined ? 0 : parseInt(e.thumbh);
					e.tabhide = e.tabhide===undefined ? 0 : parseInt(e.tabhide);
					e.thumbhide = e.thumbhide===undefined ? 0 : parseInt(e.thumbhide);
					e.mh = e.mh===undefined || e.mh=="" || e.mh==="auto" ? 0 : parseInt(e.mh,0);		
					if(e.layout==="fullscreen" || e.l==="fullscreen") 						
						newh = Math.max(e.mh,window.RSIH);					
					else{					
						e.gw = Array.isArray(e.gw) ? e.gw : [e.gw];
						for (var i in e.rl) if (e.gw[i]===undefined || e.gw[i]===0) e.gw[i] = e.gw[i-1];					
						e.gh = e.el===undefined || e.el==="" || (Array.isArray(e.el) && e.el.length==0)? e.gh : e.el;
						e.gh = Array.isArray(e.gh) ? e.gh : [e.gh];
						for (var i in e.rl) if (e.gh[i]===undefined || e.gh[i]===0) e.gh[i] = e.gh[i-1];
											
						var nl = new Array(e.rl.length),
							ix = 0,						
							sl;					
						e.tabw = e.tabhide>=pw ? 0 : e.tabw;
						e.thumbw = e.thumbhide>=pw ? 0 : e.thumbw;
						e.tabh = e.tabhide>=pw ? 0 : e.tabh;
						e.thumbh = e.thumbhide>=pw ? 0 : e.thumbh;					
						for (var i in e.rl) nl[i] = e.rl[i]<window.RSIW ? 0 : e.rl[i];
						sl = nl[0];									
						for (var i in nl) if (sl>nl[i] && nl[i]>0) { sl = nl[i]; ix=i;}															
						var m = pw>(e.gw[ix]+e.tabw+e.thumbw) ? 1 : (pw-(e.tabw+e.thumbw)) / (e.gw[ix]);					
						newh =  (e.gh[ix] * m) + (e.tabh + e.thumbh);
					}				
					if(window.rs_init_css===undefined) window.rs_init_css = document.head.appendChild(document.createElement("style"));					
					document.getElementById(e.c).height = newh+"px";
					window.rs_init_css.innerHTML += "#"+e.c+"_wrapper { height: "+newh+"px }";				
				} catch(e){
					console.log("Failure at Presize of Slider:" + e)
				}					   
			//});
		  };</script>
 
</head>
	
<body class="error404 theme-avo woocommerce-no-js avo-auto-mode elementor-default"> 
    
                           
    <!-- Dark mode switcher -->
    <div class="avo-mode-switcher cursor-as-pointer hidden-xs hidden-sm">
        <div class="avo-mode-switcher-item dark"><p class="avo-mode-switcher-item-state">Dark</p></div>
        <div class="avo-mode-switcher-item auto"><p class="avo-mode-switcher-item-state">Auto</p></div>
        <div class="avo-mode-switcher-item light"><p class="avo-mode-switcher-item-state">Light</p></div>
        <div class="avo-mode-switcher-toddler">
            <div class="avo-mode-switcher-toddler-wrap">
                <div class="avo-mode-switcher-toddler-item dark"><p class="avo-mode-switcher-item-state">Dark</p></div>
                <div class="avo-mode-switcher-toddler-item auto"><p class="avo-mode-switcher-item-state">Auto</p></div>
                <div class="avo-mode-switcher-toddler-item light"><p class="avo-mode-switcher-item-state">Light</p></div>
            </div>
        </div>
     </div>
      <div class="mouse-cursor cursor-outer"></div><div class="mouse-cursor cursor-inner"></div>
	<div id="preloader"> </div>				<nav class="header apply-header white-header clearfix 
">  
	<div class="nav-box">
		<div class="stuck-nav">
			 <div class="container-fluid">
				<div class="top-logo">
					<a href="http://avo.smartinnovates.com/demo5/">
						<img alt="Logo" class="logo1 avo-logo-dark"  style=height:25px src="http://avo.smartinnovates.com/demo5/wp-content/themes/avo/images/logo-white.png">
						<img alt="Logo" class="logo1 avo-logo-light"  style=height:25px src="http://avo.smartinnovates.com/demo5/wp-content/themes/avo/images/logo.png">
					</a>
				</div><!--End Logo-->
				
				<div class="header-wrapper  hidden-xs hidden-sm">
					<div class="main-menu menu-wrapper">
						<div class="menu-main-menu-container"><ul id="menu-main-menu" class="home-nav navigation menu"><li id="menu-item-640" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-640"><a href="http://avo.smartinnovates.com/landing">Home</a></li>
<li id="menu-item-641" class="mega-menu col4 menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-641"><a href="#0">Elements</a>
<ul class="sub-menu">
	<li id="menu-item-661" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-661"><a href="#0">Presentation</a>
	<ul class="sub-menu">
		<li id="menu-item-678" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-678"><a href="http://avo.smartinnovates.com/demo14/elements/blog-posts/">+ Blog posts</a></li>
		<li id="menu-item-676" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-676"><a href="http://avo.smartinnovates.com/demo14/elements/clients/">+ Clients</a></li>
		<li id="menu-item-683" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-683"><a href="http://avo.smartinnovates.com/demo14/elements/footer/">+ Footer</a></li>
		<li id="menu-item-662" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-662"><a href="http://avo.smartinnovates.com/demo14/elements/headers/">+ Headers</a></li>
		<li id="menu-item-677" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-677"><a href="http://avo.smartinnovates.com/demo14/elements/portfolio-projects/">+ Portfolio projects</a></li>
		<li id="menu-item-669" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-669"><a href="http://avo.smartinnovates.com/demo14/elements/team-members/">+ Team Members</a></li>
	</ul>
</li>
	<li id="menu-item-659" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-659"><a href="#0">Content</a>
	<ul class="sub-menu">
		<li id="menu-item-675" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-675"><a href="http://avo.smartinnovates.com/demo14/elements/compare/">+ Compare</a></li>
		<li id="menu-item-682" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-682"><a href="http://avo.smartinnovates.com/demo14/elements/image-box/">+ Image Box Slider</a></li>
		<li id="menu-item-684" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-684"><a href="http://avo.smartinnovates.com/demo14/elements/price-list/">+ Pricing list</a></li>
		<li id="menu-item-679" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-679"><a href="http://avo.smartinnovates.com/demo14/elements/contact-forms/">+ Contact form</a></li>
		<li id="menu-item-685" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-685"><a href="http://avo.smartinnovates.com/demo14/elements/price-table/">+ Price table</a></li>
		<li id="menu-item-663" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-663"><a href="http://avo.smartinnovates.com/demo14/elements/testimonial-elements/">+ Testimonials</a></li>
	</ul>
</li>
	<li id="menu-item-660" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-660"><a href="#0">Infographic</a>
	<ul class="sub-menu">
		<li id="menu-item-681" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-681"><a href="http://avo.smartinnovates.com/demo14/elements/featured-box/">+ Feature box</a></li>
		<li id="menu-item-664" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-664"><a href="http://avo.smartinnovates.com/demo14/elements/progress-bar/">+ Progress Bar</a></li>
		<li id="menu-item-670" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-670"><a href="http://avo.smartinnovates.com/demo14/elements/process/">+ Work Process</a></li>
		<li id="menu-item-671" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-671"><a href="http://avo.smartinnovates.com/demo14/elements/circle-progress/">+ Circle progress</a></li>
		<li id="menu-item-672" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-672"><a href="http://avo.smartinnovates.com/demo14/elements/countdown/">+ Countdown</a></li>
		<li id="menu-item-666" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-666"><a href="http://avo.smartinnovates.com/demo14/elements/info-box/">+ Info box</a></li>
	</ul>
</li>
	<li id="menu-item-658" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-658"><a href="#0">Typography</a>
	<ul class="sub-menu">
		<li id="menu-item-694" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-694"><a href="http://avo.smartinnovates.com/demo14/interactive-banner/">+ Interactive banner</a></li>
		<li id="menu-item-692" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-692"><a href="http://avo.smartinnovates.com/demo14/counters/">+ Counters</a></li>
		<li id="menu-item-693" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-693"><a href="http://avo.smartinnovates.com/demo14/videos/">+ Videos</a></li>
		<li id="menu-item-674" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-674"><a href="http://avo.smartinnovates.com/demo14/elements/heading/">+ Heading</a></li>
		<li id="menu-item-673" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-673"><a href="http://avo.smartinnovates.com/demo14/elements/call-to-action/">+ Call to action</a></li>
		<li id="menu-item-680" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-680"><a href="http://avo.smartinnovates.com/demo14/elements/buttons/">+ Buttons</a></li>
	</ul>
</li>
</ul>
</li>
<li id="menu-item-642" class="mega-menu col4 menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-642"><a href="#0">Portfolio</a>
<ul class="sub-menu">
	<li id="menu-item-646" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-646"><a href="#0">Grid layout</a>
	<ul class="sub-menu">
		<li id="menu-item-648" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-648"><a href="http://avo.smartinnovates.com/demo17/classic-boxed/">Classic boxed</a></li>
		<li id="menu-item-647" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-647"><a href="http://avo.smartinnovates.com/demo17/metro-creative/">Metro creative</a></li>
		<li id="menu-item-649" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-649"><a href="http://avo.smartinnovates.com/demo17/animated-pro/">Animated Pro</a></li>
		<li id="menu-item-704" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-704"><a href="http://avo.smartinnovates.com/demo17/portfolio-caption-cursor/">Caption Cursor</a></li>
		<li id="menu-item-705" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-705"><a href="http://avo.smartinnovates.com/demo17/masonry-animate/">Metro animate</a></li>
	</ul>
</li>
	<li id="menu-item-699" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-699"><a href="#0">Showcases</a>
	<ul class="sub-menu">
		<li id="menu-item-700" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-700"><a href="http://avo.smartinnovates.com/demo7/home07-dark">Full screen</a></li>
		<li id="menu-item-702" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-702"><a href="http://avo.smartinnovates.com/demo9/home09-dark">Column slider</a></li>
		<li id="menu-item-701" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-701"><a href="http://avo.smartinnovates.com/demo8/home08-dark">Creative carousal</a></li>
		<li id="menu-item-703" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-703"><a href="http://avo.smartinnovates.com/demo10/home10-dark">Radius slider</a></li>
	</ul>
</li>
	<li id="menu-item-644" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-644"><a href="#0">Slider layout</a>
	<ul class="sub-menu">
		<li id="menu-item-651" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-651"><a href="http://avo.smartinnovates.com/demo17/portfolio-split-slider/">Split carousel</a></li>
		<li id="menu-item-657" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-657"><a href="http://avo.smartinnovates.com/demo17/portfolio-quad-slider/">Quad Slider</a></li>
	</ul>
</li>
	<li id="menu-item-645" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-645"><a href="#0">Single project</a>
	<ul class="sub-menu">
		<li id="menu-item-650" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-650"><a href="http://avo.smartinnovates.com/demo17/portfolio/creativity-demand/">Project 1</a></li>
	</ul>
</li>
</ul>
</li>
<li id="menu-item-643" class="mega-menu col2 menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-643"><a href="#0">Blog</a>
<ul class="sub-menu">
	<li id="menu-item-655" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-655"><a href="#0">Grid layout</a>
	<ul class="sub-menu">
		<li id="menu-item-653" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-653"><a href="http://avo.smartinnovates.com/demo15/author/admin/">Blog list</a></li>
		<li id="menu-item-691" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-691"><a href="http://avo.smartinnovates.com/demo15/blog-layouts/blog-posts/">Blog slider</a></li>
		<li id="menu-item-706" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-706"><a href="http://avo.smartinnovates.com/demo15/blog-layouts/blog-staggered/">Blog Staggered</a></li>
		<li id="menu-item-707" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-707"><a href="http://avo.smartinnovates.com/demo15/blog-layouts/blog-modern/">Blog Modern</a></li>
	</ul>
</li>
	<li id="menu-item-690" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-690"><a href="#0">Single Post</a>
	<ul class="sub-menu">
		<li id="menu-item-656" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-656"><a href="http://avo.smartinnovates.com/demo15/2020/08/28/ultimate-new-guide-to-make-your-portfolio-an-awesome-work/">Single post 1</a></li>
		<li id="menu-item-689" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-689"><a href="http://avo.smartinnovates.com/demo2/2020/08/28/the-start-up-ultimate-guide-to-make-your-wordpress-journal-4/">Single post 2</a></li>
	</ul>
</li>
</ul>
</li>
<li id="menu-item-652" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-652"><a href="#0">Shop</a>
<ul class="sub-menu">
	<li id="menu-item-713" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-713"><a href="http://avo.smartinnovates.com/demo6/shop-classic/">Shop standard</a></li>
	<li id="menu-item-665" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-665"><a href="http://avo.smartinnovates.com/demo6/">Shop clean</a></li>
	<li id="menu-item-711" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-711"><a href="http://avo.smartinnovates.com/demo6/product/multi-coloured-tye/">Single product</a></li>
	<li id="menu-item-712" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-712"><a href="http://avo.smartinnovates.com/demo6/order-tracking/">Order tracking</a></li>
	<li id="menu-item-687" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-687"><a href="http://avo.smartinnovates.com/demo6/my-account/">My account</a></li>
	<li id="menu-item-686" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-686"><a href="http://avo.smartinnovates.com/demo6/checkout/">Checkout</a></li>
	<li id="menu-item-710" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-710"><a href="http://avo.smartinnovates.com/demo6/my-account/orders/">Orders</a></li>
	<li id="menu-item-688" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-688"><a href="http://avo.smartinnovates.com/demo6/my-cart/">My cart</a></li>
</ul>
</li>
<li id="menu-item-667" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-667"><a href="#0">Pages</a>
<ul class="sub-menu">
	<li id="menu-item-698" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-698"><a href="http://avo.smartinnovates.com/demo13/inner-pages/about/">About</a></li>
	<li id="menu-item-697" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-697"><a href="http://avo.smartinnovates.com/demo13/inner-pages/services/">Our Services</a></li>
	<li id="menu-item-668" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-668"><a href="http://avo.smartinnovates.com/demo13/inner-pages/contact-dark/">Contact classic</a></li>
	<li id="menu-item-708" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-708"><a href="http://avo.smartinnovates.com/demo13/inner-pages/contact-modern/">Contact modern</a></li>
	<li id="menu-item-696" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-696"><a href="http://avo.smartinnovates.com/404">Error page</a></li>
	<li id="menu-item-695" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-695"><a href="http://avo.smartinnovates.com//?s=test">Search</a></li>
	<li id="menu-item-709" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-709"><a href="http://avo.smartinnovates.com/demo13/inner-pages/faqs/">FAQs</a></li>
</ul>
</li>
<li id="menu-item-654" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-654"><a href="https://www.smartinnovates.com/themes/avo/docs/">Docs</a></li>
</ul></div>					</div><!-- End menu-wrapper -->
				
					<ul class="header-icon hidden-sm hidden-xs"> 

														<li>
									<a href="#0">
										<i class="fa fa-facebook"></i>
									</a>
								</li>
							
						
														<li>
									<a href="#0">
										<i class="fa fa-twitter"></i>
									</a>
								</li>
							
						
														<li>
									<a href="#0">
										<i class="fa fa-pinterest"></i>
									</a>
								</li>
							
												
					</ul><!-- top Socials -->


					<div class="search-icon-header hidden-xs hidden-sm">
												<a class="search"  href="#">
							<i class="fa fa-search"></i>
						</a>
						<div class="black-search-block">
							<div class="black-search-table">
								<div class="black-search-table-cell">
									<div>
																				<form role="search" method="get" id="search-form-1" class="searchform" action="http://avo.smartinnovates.com/demo5/">
											<input type="search" class="focus-input" placeholder="Type search keyword..." value="" name="s">
											<input type="submit" class="searchsubmit" value="">
										</form>
									</div>
								</div>
							</div>
							<div class="close-black-block"><a href="#"><i class="fa fa-times"></i></a></div>
						</div>
						
						
											</div>
					
				</div><!-- header-wrapper -->  

				<div class="mobile-wrapper hidden-lg hidden-md">
					<a href="#" class="hamburger"><div class="hamburger__icon"></div></a>
					<div class="fat-nav">
						<div class="fat-nav__wrapper">
							<div class="fat-list"> <ul id="menu-main-menu-1" class="mob-nav  menu"><li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-640"><a href="http://avo.smartinnovates.com/landing">Home</a></li>
<li class="mega-menu col4 menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-641"><a href="#0">Elements</a>
<ul class="sub-menu">
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-661"><a href="#0">Presentation</a>
	<ul class="sub-menu">
		<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-678"><a href="http://avo.smartinnovates.com/demo14/elements/blog-posts/">+ Blog posts</a></li>
		<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-676"><a href="http://avo.smartinnovates.com/demo14/elements/clients/">+ Clients</a></li>
		<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-683"><a href="http://avo.smartinnovates.com/demo14/elements/footer/">+ Footer</a></li>
		<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-662"><a href="http://avo.smartinnovates.com/demo14/elements/headers/">+ Headers</a></li>
		<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-677"><a href="http://avo.smartinnovates.com/demo14/elements/portfolio-projects/">+ Portfolio projects</a></li>
		<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-669"><a href="http://avo.smartinnovates.com/demo14/elements/team-members/">+ Team Members</a></li>
	</ul>
</li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-659"><a href="#0">Content</a>
	<ul class="sub-menu">
		<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-675"><a href="http://avo.smartinnovates.com/demo14/elements/compare/">+ Compare</a></li>
		<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-682"><a href="http://avo.smartinnovates.com/demo14/elements/image-box/">+ Image Box Slider</a></li>
		<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-684"><a href="http://avo.smartinnovates.com/demo14/elements/price-list/">+ Pricing list</a></li>
		<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-679"><a href="http://avo.smartinnovates.com/demo14/elements/contact-forms/">+ Contact form</a></li>
		<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-685"><a href="http://avo.smartinnovates.com/demo14/elements/price-table/">+ Price table</a></li>
		<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-663"><a href="http://avo.smartinnovates.com/demo14/elements/testimonial-elements/">+ Testimonials</a></li>
	</ul>
</li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-660"><a href="#0">Infographic</a>
	<ul class="sub-menu">
		<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-681"><a href="http://avo.smartinnovates.com/demo14/elements/featured-box/">+ Feature box</a></li>
		<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-664"><a href="http://avo.smartinnovates.com/demo14/elements/progress-bar/">+ Progress Bar</a></li>
		<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-670"><a href="http://avo.smartinnovates.com/demo14/elements/process/">+ Work Process</a></li>
		<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-671"><a href="http://avo.smartinnovates.com/demo14/elements/circle-progress/">+ Circle progress</a></li>
		<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-672"><a href="http://avo.smartinnovates.com/demo14/elements/countdown/">+ Countdown</a></li>
		<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-666"><a href="http://avo.smartinnovates.com/demo14/elements/info-box/">+ Info box</a></li>
	</ul>
</li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-658"><a href="#0">Typography</a>
	<ul class="sub-menu">
		<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-694"><a href="http://avo.smartinnovates.com/demo14/interactive-banner/">+ Interactive banner</a></li>
		<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-692"><a href="http://avo.smartinnovates.com/demo14/counters/">+ Counters</a></li>
		<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-693"><a href="http://avo.smartinnovates.com/demo14/videos/">+ Videos</a></li>
		<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-674"><a href="http://avo.smartinnovates.com/demo14/elements/heading/">+ Heading</a></li>
		<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-673"><a href="http://avo.smartinnovates.com/demo14/elements/call-to-action/">+ Call to action</a></li>
		<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-680"><a href="http://avo.smartinnovates.com/demo14/elements/buttons/">+ Buttons</a></li>
	</ul>
</li>
</ul>
</li>
<li class="mega-menu col4 menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-642"><a href="#0">Portfolio</a>
<ul class="sub-menu">
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-646"><a href="#0">Grid layout</a>
	<ul class="sub-menu">
		<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-648"><a href="http://avo.smartinnovates.com/demo17/classic-boxed/">Classic boxed</a></li>
		<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-647"><a href="http://avo.smartinnovates.com/demo17/metro-creative/">Metro creative</a></li>
		<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-649"><a href="http://avo.smartinnovates.com/demo17/animated-pro/">Animated Pro</a></li>
		<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-704"><a href="http://avo.smartinnovates.com/demo17/portfolio-caption-cursor/">Caption Cursor</a></li>
		<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-705"><a href="http://avo.smartinnovates.com/demo17/masonry-animate/">Metro animate</a></li>
	</ul>
</li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-699"><a href="#0">Showcases</a>
	<ul class="sub-menu">
		<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-700"><a href="http://avo.smartinnovates.com/demo7/home07-dark">Full screen</a></li>
		<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-702"><a href="http://avo.smartinnovates.com/demo9/home09-dark">Column slider</a></li>
		<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-701"><a href="http://avo.smartinnovates.com/demo8/home08-dark">Creative carousal</a></li>
		<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-703"><a href="http://avo.smartinnovates.com/demo10/home10-dark">Radius slider</a></li>
	</ul>
</li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-644"><a href="#0">Slider layout</a>
	<ul class="sub-menu">
		<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-651"><a href="http://avo.smartinnovates.com/demo17/portfolio-split-slider/">Split carousel</a></li>
		<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-657"><a href="http://avo.smartinnovates.com/demo17/portfolio-quad-slider/">Quad Slider</a></li>
	</ul>
</li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-645"><a href="#0">Single project</a>
	<ul class="sub-menu">
		<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-650"><a href="http://avo.smartinnovates.com/demo17/portfolio/creativity-demand/">Project 1</a></li>
	</ul>
</li>
</ul>
</li>
<li class="mega-menu col2 menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-643"><a href="#0">Blog</a>
<ul class="sub-menu">
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-655"><a href="#0">Grid layout</a>
	<ul class="sub-menu">
		<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-653"><a href="http://avo.smartinnovates.com/demo15/author/admin/">Blog list</a></li>
		<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-691"><a href="http://avo.smartinnovates.com/demo15/blog-layouts/blog-posts/">Blog slider</a></li>
		<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-706"><a href="http://avo.smartinnovates.com/demo15/blog-layouts/blog-staggered/">Blog Staggered</a></li>
		<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-707"><a href="http://avo.smartinnovates.com/demo15/blog-layouts/blog-modern/">Blog Modern</a></li>
	</ul>
</li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-690"><a href="#0">Single Post</a>
	<ul class="sub-menu">
		<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-656"><a href="http://avo.smartinnovates.com/demo15/2020/08/28/ultimate-new-guide-to-make-your-portfolio-an-awesome-work/">Single post 1</a></li>
		<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-689"><a href="http://avo.smartinnovates.com/demo2/2020/08/28/the-start-up-ultimate-guide-to-make-your-wordpress-journal-4/">Single post 2</a></li>
	</ul>
</li>
</ul>
</li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-652"><a href="#0">Shop</a>
<ul class="sub-menu">
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-713"><a href="http://avo.smartinnovates.com/demo6/shop-classic/">Shop standard</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-665"><a href="http://avo.smartinnovates.com/demo6/">Shop clean</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-711"><a href="http://avo.smartinnovates.com/demo6/product/multi-coloured-tye/">Single product</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-712"><a href="http://avo.smartinnovates.com/demo6/order-tracking/">Order tracking</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-687"><a href="http://avo.smartinnovates.com/demo6/my-account/">My account</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-686"><a href="http://avo.smartinnovates.com/demo6/checkout/">Checkout</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-710"><a href="http://avo.smartinnovates.com/demo6/my-account/orders/">Orders</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-688"><a href="http://avo.smartinnovates.com/demo6/my-cart/">My cart</a></li>
</ul>
</li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-667"><a href="#0">Pages</a>
<ul class="sub-menu">
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-698"><a href="http://avo.smartinnovates.com/demo13/inner-pages/about/">About</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-697"><a href="http://avo.smartinnovates.com/demo13/inner-pages/services/">Our Services</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-668"><a href="http://avo.smartinnovates.com/demo13/inner-pages/contact-dark/">Contact classic</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-708"><a href="http://avo.smartinnovates.com/demo13/inner-pages/contact-modern/">Contact modern</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-696"><a href="http://avo.smartinnovates.com/404">Error page</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-695"><a href="http://avo.smartinnovates.com//?s=test">Search</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-709"><a href="http://avo.smartinnovates.com/demo13/inner-pages/faqs/">FAQs</a></li>
</ul>
</li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-654"><a href="https://www.smartinnovates.com/themes/avo/docs/">Docs</a></li>
</ul></div>
						</div>
					</div>
				</div><!--End mobile-wrapper-->
				
			</div><!--End container-fluid-->
		</div><!--End stuck-nav-->
	</div><!--End nav-box-->
</nav><!--End header-->
<div class="clearfix content page-content-wrapper">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12 news-list aligncenter">
				<h2 class="error-title">404</h2>
				<p class="error-text">Oops..!!! Page not found!</p>
				<div class="spc-40 clearboth"></div>
				<a class="content-btn" href="http://avo.smartinnovates.com/demo5/">
					Go Back Now!					<span class="content-btn-align-icon-right content-btn-button-icon">
						<i class="fa fa-arrow-circle-right" aria-hidden="true"></i>
					</span>
				</a>
			</div><!--/.col-md-8-->
		</div><!--/.row-->
	</div><!--/.container-->
</div><!--/.content-->


<footer class="footer">
	<div class="container-fluid">
		
					<img class="footer-img" src="http://avo.smartinnovates.com/demo5/wp-content/themes/avo/images/logo.png" alt="LogoWhite">
		
		<div class="clearboth clearfix"></div>

		<ul class="footer-icon hidden-sm hidden-xs">
						
						
						
						
						
						
								</ul><!-- /.footer-icon -->

		<p>Copyright 2020 by ThemesCamp All Rights Reserved.</p>
	</div><!--/.container-fluid-->
</footer><!--/.footer--> 
		<!--to top button-->

		<div class="progress-wrap cursor-pointer">
			<svg class="progress-circle svg-content" width="100%" height="100%" viewBox="-1 -1 102 102">
			<path d="M50,1 a49,49 0 0,1 0,98 a49,49 0 0,1 0,-98" />
			</svg>
		</div>
		<script type="text/javascript">
		var c = document.body.className;
		c = c.replace(/woocommerce-no-js/, 'woocommerce-js');
		document.body.className = c;
	</script>
	<script id='contact-form-7-js-extra'>
var wpcf7 = {"apiSettings":{"root":"http:\/\/avo.smartinnovates.com\/demo5\/wp-json\/contact-form-7\/v1","namespace":"contact-form-7\/v1"},"cached":"1"};
</script>
<script src='http://avo.smartinnovates.com/demo5/wp-content/plugins/contact-form-7/includes/js/scripts.js?ver=5.2.2' id='contact-form-7-js'></script>
<script src='http://avo.smartinnovates.com/demo5/wp-content/plugins/woocommerce/assets/js/jquery-blockui/jquery.blockUI.min.js?ver=2.70' id='jquery-blockui-js'></script>
<script id='wc-add-to-cart-js-extra'>
var wc_add_to_cart_params = {"ajax_url":"\/demo5\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/demo5\/?wc-ajax=%%endpoint%%","i18n_view_cart":"View cart","cart_url":"http:\/\/avo.smartinnovates.com\/demo5","is_cart":"","cart_redirect_after_add":"no"};
</script>
<script src='http://avo.smartinnovates.com/demo5/wp-content/plugins/woocommerce/assets/js/frontend/add-to-cart.min.js?ver=4.5.1' id='wc-add-to-cart-js'></script>
<script src='http://avo.smartinnovates.com/demo5/wp-content/plugins/woocommerce/assets/js/js-cookie/js.cookie.min.js?ver=2.1.4' id='js-cookie-js'></script>
<script id='woocommerce-js-extra'>
var woocommerce_params = {"ajax_url":"\/demo5\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/demo5\/?wc-ajax=%%endpoint%%"};
</script>
<script src='http://avo.smartinnovates.com/demo5/wp-content/plugins/woocommerce/assets/js/frontend/woocommerce.min.js?ver=4.5.1' id='woocommerce-js'></script>
<script id='wc-cart-fragments-js-extra'>
var wc_cart_fragments_params = {"ajax_url":"\/demo5\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/demo5\/?wc-ajax=%%endpoint%%","cart_hash_key":"wc_cart_hash_71c905f392570c72df217e99403dbb82","fragment_name":"wc_fragments_71c905f392570c72df217e99403dbb82","request_timeout":"5000"};
</script>
<script src='http://avo.smartinnovates.com/demo5/wp-content/plugins/woocommerce/assets/js/frontend/cart-fragments.min.js?ver=4.5.1' id='wc-cart-fragments-js'></script>
<script src='http://avo.smartinnovates.com/demo5/wp-content/themes/avo/js/bootstrap.min.js?ver=5.5.3' id='bootstrap-js'></script>
<script src='http://avo.smartinnovates.com/demo5/wp-includes/js/jquery/ui/effect.min.js?ver=1.11.4' id='jquery-effects-core-js'></script>
<script src='http://avo.smartinnovates.com/demo5/wp-content/themes/avo/js/superfish.js?ver=5.5.3' id='superfish-js'></script>
<script src='http://avo.smartinnovates.com/demo5/wp-content/themes/avo/js/pace.min.js?ver=5.5.3' id='pace-js'></script>
<script src='http://avo.smartinnovates.com/demo5/wp-content/themes/avo/js/jquery.fitvids.js?ver=5.5.3' id='jquery-fitvids-js'></script>
<script src='http://avo.smartinnovates.com/demo5/wp-content/themes/avo/js/jquery.magnific-popup.min.js?ver=5.5.3' id='jquery-magnific-popup-js'></script>
<script src='http://avo.smartinnovates.com/demo5/wp-content/themes/avo/js/jquery.sticky.js?ver=5.5.3' id='jquery-sticky-js'></script>
<script src='http://avo.smartinnovates.com/demo5/wp-includes/js/imagesloaded.min.js?ver=4.1.4' id='imagesloaded-js'></script>
<script src='http://avo.smartinnovates.com/demo5/wp-content/themes/avo/js/slick.min.js?ver=5.5.3' id='slick-js'></script>
<script src='http://avo.smartinnovates.com/demo5/wp-content/themes/avo/js/slick-animation.js?ver=5.5.3' id='slick-animation-js'></script>
<script src='http://avo.smartinnovates.com/demo5/wp-content/themes/avo/js/ResizeSensor.min.js?ver=5.5.3' id='resizesensor-js'></script>
<script src='http://avo.smartinnovates.com/demo5/wp-content/themes/avo/js/theia-sticky-sidebar.min.js?ver=5.5.3' id='theia-sticky-sidebar-js'></script>
<script src='http://avo.smartinnovates.com/demo5/wp-content/themes/avo/js/svgembedder.min.js?ver=5.5.3' id='svgembedder-js'></script>
<script src='http://avo.smartinnovates.com/demo5/wp-content/themes/avo/js/totop.js?ver=5.5.3' id='avo-totop-js'></script>
<script src='http://avo.smartinnovates.com/demo5/wp-content/plugins/avo_plugin/widgets/js/animated.headline.js' id='animated-headline-js'></script>
<script src='http://avo.smartinnovates.com/demo5/wp-content/plugins/avo_plugin/widgets/js/splitting.min.js' id='splitting-js'></script>
<script src='http://avo.smartinnovates.com/demo5/wp-content/themes/avo/js/isotope.pkgd.min.js?ver=5.5.3' id='isotope.pkgd-js'></script>
<script src='http://avo.smartinnovates.com/demo5/wp-content/plugins/elementor/assets/lib/swiper/swiper.min.js?ver=5.3.6' id='swiper-js'></script>
<script src='http://avo.smartinnovates.com/demo5/wp-content/themes/avo/js/slider-swiper.js?ver=5.5.3' id='slider-swiper-js'></script>
<script src='http://avo.smartinnovates.com/demo5/wp-content/plugins/avo_plugin/widgets/js/simpleParallax.min.js' id='simpleParallax-js'></script>
<script src='http://avo.smartinnovates.com/demo5/wp-content/themes/avo/js/waypoints.min.js?ver=5.5.3' id='waypoints-js'></script>
<script src='http://avo.smartinnovates.com/demo5/wp-content/themes/avo/js/jquery.counterup.min.js?ver=5.5.3' id='jquery-counterup-js'></script>
<script src='http://avo.smartinnovates.com/demo5/wp-content/themes/avo/js/jquery.knob.js?ver=5.5.3' id='jquery-knob-js'></script>
<script src='http://avo.smartinnovates.com/demo5/wp-content/themes/avo/js/wow.min.js?ver=5.5.3' id='jquery-wow-js'></script>
<script src='http://avo.smartinnovates.com/demo5/wp-content/themes/avo/js/jquery.appear.js?ver=5.5.3' id='jquery-appear-js'></script>
<script src='http://avo.smartinnovates.com/demo5/wp-content/themes/avo/js/scripts.js?ver=5.5.3' id='avo-scripts-js'></script>
<script src='http://avo.smartinnovates.com/demo5/wp-content/themes/avo/js/loader.js?ver=5.5.3' id='preloader-js'></script>
<script src='http://avo.smartinnovates.com/demo5/wp-includes/js/wp-embed.min.js?ver=5.5.3' id='wp-embed-js'></script>
	</body>
</html>